# app_template_csclient - app framework using csclient.py
from csclient import EventingCSClient
cp = EventingCSClient('app_template_csclient')
cp.log('Starting...')
