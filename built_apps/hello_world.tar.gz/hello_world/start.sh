#!/bin/bash
cppython hello_world.py