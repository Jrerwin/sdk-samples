#!/bin/bash
cppython cpu_usage.py
