#!/bin/bash
cppython shell_sample.py