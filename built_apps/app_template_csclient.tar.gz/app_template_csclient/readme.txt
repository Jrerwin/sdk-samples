Application Name
================
app_template_csclient


Application Version
===================
1.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This is a template using SDK v3.0 csclient.py


Expected Output
===============
Info Level Log Message: "Starting..."

