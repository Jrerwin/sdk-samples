#!/bin/bash
cppython Boot2.py
