#!/bin/bash
cppython OBDII_monitor.py