Application Name
================
serial_temp


Application Version
===================
2.0


NCOS Devices Supported
======================
All


Application Purpose
===================
This is a test application to serial data from the data logger connected
to the router and output that to MQTT messages that are forwarded from the
router to Azure IoT Central.

