#!/bin/bash
cppython geofences.py