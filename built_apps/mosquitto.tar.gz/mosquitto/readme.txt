Application Name
================
mosquitto (not python)


Application Version
===================
1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
* Not a python application

Start NCOS-native mosquitto server using including mosquitto.conf file


Expected Output
===============
Mosquitto server running on specified port

