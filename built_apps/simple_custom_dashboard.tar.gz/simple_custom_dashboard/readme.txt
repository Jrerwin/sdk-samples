Application Name
================
simple_custom_dashboard


Application Version
===================
2.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
Demonstrate a custom dashboard using the http library
which is included in NCOS.


Expected Output
===============
The custom dashboard should be displayed when using
NCM remote connect to the device via 127.0.0.1 9001.
To access the dashboard without NCM, the port will
need to be opened in the device firewall.

