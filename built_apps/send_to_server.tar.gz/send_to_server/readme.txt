Application Name
================
send_to_server


Application Version
===================
2.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
This application uses test server http://httpbin.org/post.


Application Purpose
===================
Demonstrates send a post request to a server with some device information
using python library urllib which is included in NCOS.


Expected Output
===============
Data should be sent to test server http://httpbin.org/post. It also logs
the time it took to gather and send the data.

