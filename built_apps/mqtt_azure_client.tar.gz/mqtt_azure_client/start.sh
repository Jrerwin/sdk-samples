#!/bin/bash
cppython mqtt_azure_client.py
