#!/bin/bash
cppython tornado_sample.py
