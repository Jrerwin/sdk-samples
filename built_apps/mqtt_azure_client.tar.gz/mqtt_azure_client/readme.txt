Application Name
================
mqtt_azure_client


Application Version
===================
2.0


NCOS Devices Supported
======================
All


External Requirements
=====================
None


Application Purpose
===================
Sample Application which uses SDK to send sensor data to
Microsoft Azure IoT Central.

