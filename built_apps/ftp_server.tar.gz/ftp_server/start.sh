#!/bin/bash
cppython ftp_server.py