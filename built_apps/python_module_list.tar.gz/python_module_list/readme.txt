Application Name
================
python_module_list


Application Version
===================
2.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This application will output logs showing the python version
and files included in the NCOS of the device. This is a subset
of the files that are included in a python downloaded to a
computer.


Expected Output
===============
Log that indicate the python version and files included in
the NCOS of the device.

