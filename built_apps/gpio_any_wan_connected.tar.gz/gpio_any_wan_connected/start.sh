#!/bin/bash
cppython gpio_any_wan_connected.py