#!/bin/bash
cppython AutoInstall.py
