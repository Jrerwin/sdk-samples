#!/bin/bash
cppython mqtt_app.py